class SplashModel {
  final String logoPath;
  final String subtitile;

  SplashModel({
    required this.logoPath,
    required this.subtitile,
  });
}