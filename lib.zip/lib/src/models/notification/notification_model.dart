class NotificationModel {
  String? title ;
  String? description;
  NotificationModel({required this.title, required this.description});
}
