class ProductOrderModel {
  final String? name;
  final String? type;
  final String? quntity;
  final double? price;
  ProductOrderModel({this.name, this.type, this.quntity, this.price});
}
