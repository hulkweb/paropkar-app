/// Strings
class AppStrings {
  static const String appName = "My Flutter App";
  static const String splash_subtitile = "paropkar wholesale mart";
  static const String loginButton = "Login";
  static const String signUpButton = "Sign Up";
  static const String errorMessage = "Something went wrong. Please try again.";
}