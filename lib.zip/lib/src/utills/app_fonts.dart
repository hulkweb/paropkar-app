class AppFonts{
  static const String bold = 'PoppinsBold';
  static const String extraBold = 'PoppinsExtraBold';
  static const String medium = 'PoppinsMedium';
  static const String light = 'PoppinsLight';
  static const String regular = 'PoppinsRegular';
  static const String semiBold = 'PoppinsSemiBold';
  static const String thin = 'PoppinsThin';
  static const String black = 'PoppinsBlack';
}









