import 'package:flutter/cupertino.dart';

Widget verySmallHeight = const SizedBox(
  height: 5,
);
Widget smallHeight = const SizedBox(
  height: 10,
);
Widget mediumHeight = const SizedBox(
  height: 20,
);
Widget largeHeight = const SizedBox(
  height: 30,
);

Widget verySmallWidth = const SizedBox(
  width: 5,
);
Widget smallWidth = const SizedBox(
  width: 10,
);
Widget mediumWidth = const SizedBox(
  width: 20,
);
Widget largeWidth = const SizedBox(
  width: 30,
);



