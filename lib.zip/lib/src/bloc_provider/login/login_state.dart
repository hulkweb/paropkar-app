// // login_state.dart
// abstract class LoginState {}

// class LoginInitial extends LoginState {
//   final bool isOtpGet;
//   LoginInitial({this.isOtpGet = false});
// }

// class LoginLoading extends LoginState {}

// class LoginWithOtpState extends LoginState {}

// class LoginWithPasswordState extends LoginState {}

// class MobileVerified extends LoginState {}

// class LoginSuccess extends LoginState {}

// class LoginFailure extends LoginState {
//   final String error;
//   LoginFailure(this.error);
// }
