// abstract class ProductEvent {}

// class FetchProducts extends ProductEvent {}

// class FetchProductDetail extends ProductEvent {
//   final String id;

//   FetchProductDetail({required this.id});
// }
