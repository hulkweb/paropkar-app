// abstract class CartEvent {}

// // Fetch cart event
// class FetchCart extends CartEvent {}

// // Add item to cart event
// class AddCartItem extends CartEvent{
//   final String productId;
//   final String quantity;

//   AddCartItem({
//     required this.productId,
//     required this.quantity,
//   });
// }

// // Remove item from cart event
// class RemoveCartItem extends CartEvent {
//   final String productId;
//   final String variationId;

//   RemoveCartItem({
//     required this.productId,
//     required this.variationId,
//   });
// }