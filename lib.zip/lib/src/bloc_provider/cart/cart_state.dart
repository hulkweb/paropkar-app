
// import 'package:paropkar/src/models/cart/cart_model.dart';

// abstract class CartState {}

// class CartLoading extends CartState {}

// class CartSuccess extends CartState {
//   final CartModel cartData;
//   CartSuccess(this.cartData);
// }

// class CartFailure extends CartState {
//   final String errorMessage;
//   CartFailure(this.errorMessage);
// }

// class AddCartLoading extends CartState {}

// class AddCartSuccess extends CartState {
//    final String successMessage;
//   AddCartSuccess(this.successMessage);
// }

// class AddCartFailure extends CartState {
//   final String errorMessage;
//   AddCartFailure(this.errorMessage);
// }

// // Remove item from cart loading
// class RemoveCartLoading extends CartState {}

// // Remove item from cart success
// class RemoveCartSuccess extends CartState {}

// // Remove item from cart failure
// class RemoveCartFailure extends CartState {
//   final String errorMessage;
//   RemoveCartFailure(this.errorMessage);
// }
