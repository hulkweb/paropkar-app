// abstract class CategoryEvent{}

// class FetchCategories extends CategoryEvent{}