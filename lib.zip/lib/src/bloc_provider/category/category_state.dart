// import 'package:paropkar/src/models/category/category_listing_models.dart';

// abstract class CategoryState {}

// class CategoryLoading extends CategoryState {}

// class CategorySuccess extends CategoryState {
//   final CategoriesListModel categoryData;
//   CategorySuccess(this.categoryData);
// }

// class CategoryFailure extends CategoryState {
//   final String errorMessage;
//   CategoryFailure(this.errorMessage);
// }
