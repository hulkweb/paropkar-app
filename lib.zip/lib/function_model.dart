// //postApi
// postApiFunc(BuildContext context) {
//     postApi(
//       body: {'mobile': mobileFieldController.value},
//       url: '',
//       context: context,
//       onSuccess: (response) {},
//       onFailed: (response) {},
//       onException: () {},
//     );
//   }

// //getApi
//  getApiFunc(BuildContext context) {
//     getApi(
//       url: '',
//       context: context,
//       onSuccess: (response) {},
//       onFailed: (response) {
// showDialogBox(context,type: 'error',);
// },
//       onException: () {},
//     );
//   }